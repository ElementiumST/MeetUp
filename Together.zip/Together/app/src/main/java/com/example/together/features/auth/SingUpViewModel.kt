package com.example.together.features.auth

import androidx.lifecycle.ViewModel

class SingUpViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}