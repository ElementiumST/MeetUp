package com.example.together.features.static

import android.R
import android.content.Context
import android.content.res.Resources.Theme
import android.util.TypedValue
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes

@ColorRes
fun getStylizedColorId(context: Context, attrId: Int):Int {
    val typedValue = TypedValue()
    val theme: Theme = context.theme
    theme.resolveAttribute(attrId, typedValue, true)
    return typedValue.data
}