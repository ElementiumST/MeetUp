package com.example.together.features.views.auth

import android.content.Context
import android.graphics.Color
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.util.AttributeSet
import android.util.Log
import androidx.appcompat.widget.AppCompatButton
import com.example.together.R
import com.example.together.features.static.getStylizedColorId


class TwoColorNonAccentButton: AppCompatButton {
    private var primaryText: String = ""
    var secondaryText: String = ""
    constructor(context: Context) : super(context) {
        init()
    }
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs){
        hookAttributes(attrs)
        init()
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        hookAttributes(attrs)
        init()
    }

    private fun hookAttributes(attrs: AttributeSet?) {
        val typedArray = context.obtainStyledAttributes(
            attrs,
            R.styleable.TwoColorNonAccentButton,
            0,
            0
        )
        isAllCaps = false
        try {
            primaryText = typedArray.getString(R.styleable.TwoColorNonAccentButton_primaryText)?: ""
            secondaryText = typedArray.getString(R.styleable.TwoColorNonAccentButton_secondText)?: ""
        } finally {
            typedArray.recycle()
        }
    }

    private fun init() {
        setBackgroundColor(
            resources.getColor(
                R.color.white,
                context.theme
            )
        )
        setTextColor(
            resources.getColor(
                R.color.grey_500,
                context.theme
            )
        )
        text = SpannableString("$primaryText $secondaryText").apply {
            setSpan(
                ForegroundColorSpan(resources.getColor(
                    R.color.green_500,
                    context.theme)),
                0,
                primaryText.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }


    }
}