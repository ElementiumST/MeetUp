package com.example.together.features.auth

import androidx.lifecycle.ViewModel

class SignInViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}